﻿using ClosedXML.Excel;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace SearchADORepo
{
    class SearchADORepo
    {
        static async Task Main(string[] args)
        {
            //The AZure Devops Input Values. Personal Access Token(PAT) can be created at https://microsoftit.visualstudio.com/_usersSettings/tokens 
            string PAT = "EnteryourPATTokenHere";
            string orgnization = "MicrosoftIT";
            string project = "OneITVSO";
            string repository = "BAS-BOC-CCD-Commhw-CommHW";
            string searchText = "Thumbprint, serialnumber";
            string fileTypes = "xml,config";
            Console.WriteLine("PAT :" + PAT);
            Console.WriteLine("Orgnization : " + orgnization);
            Console.WriteLine("Project : " + project);
            Console.WriteLine("Repository : " + repository);
            Console.WriteLine("SearchText in comma separated: " + searchText);
            Console.WriteLine("Search File Types in comma separated, to search all input * ex: XML, conifig : " + fileTypes);
            Console.Write("Are you sure you want to continue search with above values? [Y/N]: ");

            string overwrite = Console.ReadLine();
            if (overwrite.ToUpper().Equals("N") || overwrite.ToUpper().Equals("NO"))
            {
                //Confirming the User Input
                Console.WriteLine("Enter the input parameter values and Search text keywords here..");
                Console.Write("PAT, you can create a new PAT at https://microsoftit.visualstudio.com/_usersSettings/tokens : ");
                PAT = Console.ReadLine();

                Console.Write("Orgnization ex: MicrosoftIT : ");
                orgnization = Console.ReadLine();

                Console.Write("Project ex:OneITVSO : ");
                project = Console.ReadLine();

                Console.Write("Repository : ");
                repository = Console.ReadLine();

                Console.Write("SearchText in comma separated: ");
                searchText = Console.ReadLine();

                Console.Write("Search File Types in comma separated, to search all input * ex: XML, conifig : ");
                fileTypes = Console.ReadLine();
            }

            try
            {
                DataSet dsResult = new DataSet();
                dsResult = await SearchDevopsRepo(PAT, orgnization, project, repository, searchText, fileTypes).ConfigureAwait(false);

                // Export SearchResult to Excel.
                string appLocation = "";
                appLocation = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
                appLocation = appLocation.Replace("file:\\", "");
                string date = DateTime.Now.ToString();
                date = date.Replace("/", "_");
                date = date.Replace(":", "-");

                // Search response will be saved in excel file located at ex ..\AzureDevopsPAT\bin\Debug\netcoreapp3.1\ExcelFiles\SearchResult_6_12_2020.xlsx"
                string filePath = appLocation + "\\ExcelFiles\\" + "SearchResult_" + date + ".xlsx";

                using (XLWorkbook wb = new XLWorkbook())
                {
                    if (dsResult.Tables.Count != 0)
                    {
                        foreach (System.Data.DataTable dt in dsResult.Tables)
                        {
                            if (dt.TableName.Length > 31)
                            {
                                wb.Worksheets.Add(dt, dt.TableName.Substring(0, 31));
                            }
                            else
                            {
                                wb.Worksheets.Add(dt, dt.TableName);
                            }
                        }
                    }
                    else
                    {
                        wb.Worksheets.Add();
                    }
                    wb.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    wb.Style.Font.Bold = true;
                    wb.SaveAs(filePath);
                    Console.WriteLine("Excel file saved at: " + filePath);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private static async Task<DataSet> SearchDevopsRepo(string PAT, string orgnization, string project, string repository, string searchtext, string filetypes)
        {
            DataSet ds = new DataSet();
            foreach (var searchtxt in searchtext.Split(','))
            {
                var personalaccesstoken = PAT;
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Accept.Add(
                        new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic",
                        Convert.ToBase64String(
                            System.Text.ASCIIEncoding.ASCII.GetBytes(
                                string.Format("{0}:{1}", "", personalaccesstoken))));


                    SearchInput input = new SearchInput
                    {
                        searchText = searchtxt.Trim(),  // Text to search
                        skip = 0,
                        top = 1000,
                        filters = new Filters
                        {
                            Project = new List<string> { project },
                            Repository = new List<string> { repository },
                            Branch = new List<string> { "master" },
                            Path = new List<string> { "/" },
                            CodeElement = new List<string> { "strlit" },   // Filters -String literals
                        },
                        orderBy = new List<OrderBy> { new OrderBy { field = "filename", sortOrder = "ASC" } },
                        includeFacets = true
                    };

                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(input);

                    //Calling the Azure Search URI provided by DSRE team
                    string searchURI = "https://almsearch.dev.azure.com/{0}/{1}/_apis/search/codesearchresults?api-version=5.1-preview.1";
                    using var request = new HttpRequestMessage(HttpMethod.Post, string.Format(searchURI, orgnization, project))
                    {
                        Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json")
                    };

                    Console.WriteLine("Searching for text " + input.searchText + "...\n");
                    using var response = await client
                            .SendAsync(request, HttpCompletionOption.ResponseHeadersRead)
                            .ConfigureAwait(false);
                    response.EnsureSuccessStatusCode();
                    string responseBody = await response.Content.ReadAsStringAsync();

                    SearchResult result = JsonConvert.DeserializeObject<SearchResult>(responseBody);

                    if (result.results.Any())
                    {
                        var searchResult = new System.Data.DataTable
                        {
                            TableName = searchtxt
                        };
                        searchResult.Columns.Add("FileName", typeof(string));
                        searchResult.Columns.Add("Path", typeof(string));
                        Console.WriteLine("\t" + "FileName" + "\t" + "Path" + "\n");

                        char[] splitChar = { '.' };
                        for (int i = 0; i < result.results.Count; i++)
                        {
                            foreach (var filetype in filetypes.Split(','))
                            {
                                if (!filetype.ToString().Contains("*"))
                                {
                                    string fileTypeExtension = result.results[i].fileName.Split(splitChar).Last();
                                    if (fileTypeExtension == filetype.Trim().ToString())
                                    {
                                        if (result.results[i].fileName.Contains("css"))
                                        {
                                            Console.WriteLine("unwanted");
                                        }
                                        Console.WriteLine(i + 1 + "\t" + result.results[i].fileName + "\t" + result.results[i].path + "\n");
                                        searchResult.Rows.Add(result.results[i].fileName, result.results[i].path);
                                    }
                                }
                                else
                                {
                                    Console.WriteLine(i + 1 + "\t" + result.results[i].fileName + "\t" + result.results[i].path + "\n");
                                    searchResult.Rows.Add(result.results[i].fileName, result.results[i].path);
                                }
                            }
                        }
                        Console.WriteLine("Total Search Results Count= " + result.count + "\n");

                        ds.Tables.Add(searchResult);
                    }
                    else
                    {
                        Console.WriteLine("No results Found for the given input string in the given repo. \n");
                    }
                }
            }
            return ds;
        }
    }
}
