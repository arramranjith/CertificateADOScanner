﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace SearchADORepo
{
    public class SearchInput
    {
        public string searchText { get; set; }

        [JsonProperty("$skip")]
        public int skip { get; set; }
        [JsonProperty("$top")]
        public int top { get; set; }
        public Filters filters { get; set; }
        [JsonProperty("$orderBy ")]
        public IList<OrderBy> orderBy { get; set; }
        public bool includeFacets { get; set; }
    }

    public class Filters
    {
        public IList<string> Project { get; set; }
        public IList<string> Repository { get; set; }
        public IList<string> Path { get; set; }
        public IList<string> Branch { get; set; }
        public IList<string> CodeElement { get; set; }

    }

    public class OrderBy
    {
        public string field { get; set; }
        public string sortOrder { get; set; }
    }
}
